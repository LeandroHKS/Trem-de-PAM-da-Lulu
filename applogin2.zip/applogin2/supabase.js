import 'react-native-url-polyfill/auto';
import { createClient } from '@supabase/supabase-js';
const supabaseUrl = 'https://mttevufzwkgdmlodzxsj.supabase.co';
const supabaseKey = 'sb_publishable_3_h0vIocIXo0iXuttFpABg_GT1ecsjq';
export const supabase = createClient(
  supabaseUrl,
  supabaseKey
);