import React, { useState } from 'react';

import {
  View,
  Text,
  TextInput,
  TouchableOpacity,
  StyleSheet,
  Alert,
} from 'react-native';

import { NavigationContainer } from '@react-navigation/native';
import { createNativeStackNavigator } from '@react-navigation/native-stack';
import { createClient } from '@supabase/supabase-js';

import Cadastro from './cadastro';

const supabaseUrl = 'https://mttevufzwkgdmlodzxsj.supabase.co';

const supabaseKey =
  'sb_publishable_iG3p1w7lYSYE9ST6JuZh3A_1F3Y58A4';

const supabase = createClient(
  supabaseUrl,
  supabaseKey
);

const Stack = createNativeStackNavigator();

function Login({ navigation }) {
  const [email, setEmail] = useState('');
  const [senha, setSenha] = useState('');

  async function entrar() {
    if (!email.trim() || !senha) {
      Alert.alert(
        'Campos obrigatórios',
        'Preencha seu e-mail e sua senha.'
      );
      return;
    }

    try {
      const { error } = await supabase.auth.signInWithPassword({
        email: email.trim().toLowerCase(),
        password: senha,
      });

      if (error) {
        Alert.alert(
          'Erro no login',
          error.message
        );
        return;
      }

      Alert.alert(
        'Login realizado!',
        'Bem-vindo de volta!'
      );

    } catch (erro) {
      console.log(erro);

      Alert.alert(
        'Erro',
        'Não foi possível realizar o login.'
      );
    }
  }

  return (
    <View style={styles.container}>

      <View style={styles.card}>

        <View style={styles.cabecalho}>

          <Text style={styles.icone}>
            🔐
          </Text>

          <Text style={styles.titulo}>
            Bem-vindo!
          </Text>

          <Text style={styles.subtitulo}>
            Entre na sua conta para continuar
          </Text>

        </View>

        <TextInput
          style={styles.campo}
          placeholder="E-mail"
          placeholderTextColor="#9ca3af"
          keyboardType="email-address"
          autoCapitalize="none"
          value={email}
          onChangeText={setEmail}
        />

        <TextInput
          style={styles.campo}
          placeholder="Senha"
          placeholderTextColor="#9ca3af"
          secureTextEntry
          value={senha}
          onChangeText={setSenha}
        />

        <TouchableOpacity
          style={styles.botao}
          activeOpacity={0.8}
          onPress={entrar}
        >
          <Text style={styles.textoBotao}>
            Entrar
          </Text>
        </TouchableOpacity>

        <View style={styles.divisor}>

          <View style={styles.linha} />

          <Text style={styles.textoDivisor}>
            ou
          </Text>

          <View style={styles.linha} />

        </View>

        <TouchableOpacity
          style={styles.botaoCadastro}
          activeOpacity={0.8}
          onPress={() => navigation.navigate('Cadastro')}
        >
          <Text style={styles.textoCadastro}>
            Criar uma conta
          </Text>
        </TouchableOpacity>

      </View>

      <Text style={styles.rodape}>
        Faça login ou crie sua conta para começar.
      </Text>

    </View>
  );
}

export default function App() {
  return (
    <NavigationContainer>

      <Stack.Navigator
        initialRouteName="Login"
        screenOptions={{
          headerShown: false,
        }}
      >

        <Stack.Screen
          name="Login"
          component={Login}
        />

        <Stack.Screen
          name="Cadastro"
          component={Cadastro}
        />

      </Stack.Navigator>

    </NavigationContainer>
  );
}

const styles = StyleSheet.create({

  container: {
    flex: 1,
    justifyContent: 'center',
    paddingHorizontal: 22,
    backgroundColor: '#f1f5f9',
  },

  card: {
    backgroundColor: '#ffffff',
    borderRadius: 24,
    padding: 25,

    shadowColor: '#000',
    shadowOffset: {
      width: 0,
      height: 5,
    },
    shadowOpacity: 0.10,
    shadowRadius: 12,
    elevation: 6,
  },

  cabecalho: {
    alignItems: 'center',
    marginBottom: 28,
  },

  icone: {
    fontSize: 42,
    marginBottom: 8,
  },

  titulo: {
    fontSize: 30,
    fontWeight: 'bold',
    color: '#1e3a8a',
    marginBottom: 6,
  },

  subtitulo: {
    fontSize: 14,
    color: '#64748b',
    textAlign: 'center',
  },

  campo: {
    height: 52,
    backgroundColor: '#f8fafc',
    borderWidth: 1,
    borderColor: '#e2e8f0',
    borderRadius: 12,
    paddingHorizontal: 16,
    fontSize: 16,
    color: '#1e293b',
    marginBottom: 14,
  },

  botao: {
    height: 54,
    backgroundColor: '#2563eb',
    borderRadius: 12,
    alignItems: 'center',
    justifyContent: 'center',
    marginTop: 4,

    shadowColor: '#2563eb',
    shadowOffset: {
      width: 0,
      height: 4,
    },
    shadowOpacity: 0.25,
    shadowRadius: 6,
    elevation: 4,
  },

  textoBotao: {
    color: '#ffffff',
    fontSize: 16,
    fontWeight: 'bold',
    letterSpacing: 0.2,
  },

  divisor: {
    flexDirection: 'row',
    alignItems: 'center',
    marginVertical: 20,
  },

  linha: {
    flex: 1,
    height: 1,
    backgroundColor: '#e2e8f0',
  },

  textoDivisor: {
    color: '#94a3b8',
    fontSize: 13,
    marginHorizontal: 12,
  },

  botaoCadastro: {
    height: 52,
    backgroundColor: '#ffffff',
    borderWidth: 2,
    borderColor: '#2563eb',
    borderRadius: 12,
    alignItems: 'center',
    justifyContent: 'center',
  },

  textoCadastro: {
    color: '#2563eb',
    fontSize: 16,
    fontWeight: 'bold',
  },

  rodape: {
    textAlign: 'center',
    color: '#94a3b8',
    fontSize: 12,
    marginTop: 18,
  },

});