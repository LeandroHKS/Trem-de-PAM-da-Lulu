import React, { useState } from 'react';

import {
  View,
  Text,
  TextInput,
  TouchableOpacity,
  StyleSheet,
  Alert,
} from 'react-native';

import { createClient } from '@supabase/supabase-js';

const supabaseUrl = 'https://mttevufzwkgdmlodzxsj.supabase.co';

const supabaseKey =
  'sb_publishable_iG3p1w7lYSYE9ST6JuZh3A_1F3Y58A4';

const supabase = createClient(
  supabaseUrl,
  supabaseKey
);

export default function Cadastro({ navigation }) {
  const [nome, setNome] = useState('');
  const [email, setEmail] = useState('');
  const [senha, setSenha] = useState('');
  const [confirmarSenha, setConfirmarSenha] = useState('');

  async function cadastrarUsuario() {
    if (
      !nome.trim() ||
      !email.trim() ||
      !senha ||
      !confirmarSenha
    ) {
      Alert.alert(
        'Campos obrigatórios',
        'Preencha todos os campos para continuar.'
      );
      return;
    }

    if (senha.length < 6) {
      Alert.alert(
        'Senha inválida',
        'A senha deve ter pelo menos 6 caracteres.'
      );
      return;
    }

    if (senha !== confirmarSenha) {
      Alert.alert(
        'Senhas diferentes',
        'As senhas informadas não são iguais.'
      );
      return;
    }

    try {
      const { data, error } = await supabase.auth.signUp({
        email: email.trim().toLowerCase(),
        password: senha,
        options: {
          data: {
            nome: nome.trim(),
          },
        },
      });

      if (error) {
        Alert.alert(
          'Erro no cadastro',
          error.message
        );
        return;
      }

      if (data.session) {
        Alert.alert(
          'Cadastro realizado!',
          'Sua conta foi criada com sucesso.'
        );

        navigation.navigate('Login');
      } else {
        Alert.alert(
          'Cadastro realizado!',
          'Sua conta foi criada. Verifique seu e-mail para confirmar o cadastro.'
        );

        navigation.navigate('Login');
      }

    } catch (erro) {
      console.log(erro);

      Alert.alert(
        'Erro',
        'Não foi possível realizar o cadastro.'
      );
    }
  }

  return (
    <View style={styles.container}>

      <View style={styles.card}>

        <View style={styles.cabecalho}>

          <Text style={styles.icone}>
            👤
          </Text>

          <Text style={styles.titulo}>
            Criar conta
          </Text>

          <Text style={styles.subtitulo}>
            Preencha seus dados para começar
          </Text>

        </View>

        <TextInput
          style={styles.campo}
          placeholder="Nome completo"
          placeholderTextColor="#9ca3af"
          autoCapitalize="words"
          value={nome}
          onChangeText={setNome}
        />

        <TextInput
          style={styles.campo}
          placeholder="E-mail"
          placeholderTextColor="#9ca3af"
          keyboardType="email-address"
          autoCapitalize="none"
          value={email}
          onChangeText={setEmail}
        />

        <TextInput
          style={styles.campo}
          placeholder="Senha"
          placeholderTextColor="#9ca3af"
          secureTextEntry
          value={senha}
          onChangeText={setSenha}
        />

        <TextInput
          style={styles.campo}
          placeholder="Confirme sua senha"
          placeholderTextColor="#9ca3af"
          secureTextEntry
          value={confirmarSenha}
          onChangeText={setConfirmarSenha}
        />

        <TouchableOpacity
          style={styles.botaoCadastro}
          activeOpacity={0.8}
          onPress={cadastrarUsuario}
        >
          <Text style={styles.textoBotao}>
            Criar minha conta
          </Text>
        </TouchableOpacity>

        <TouchableOpacity
          style={styles.botaoVoltar}
          activeOpacity={0.7}
          onPress={() => navigation.goBack()}
        >
          <Text style={styles.textoVoltar}>
            ← Voltar ao Login
          </Text>
        </TouchableOpacity>

      </View>

      <Text style={styles.rodape}>
        Seus dados estão seguros conosco.
      </Text>

    </View>
  );
}

const styles = StyleSheet.create({

  container: {
    flex: 1,
    justifyContent: 'center',
    paddingHorizontal: 22,
    backgroundColor: '#f1f5f9',
  },

  card: {
    backgroundColor: '#ffffff',
    borderRadius: 24,
    padding: 25,

    shadowColor: '#000',
    shadowOffset: {
      width: 0,
      height: 5,
    },
    shadowOpacity: 0.10,
    shadowRadius: 12,
    elevation: 6,
  },

  cabecalho: {
    alignItems: 'center',
    marginBottom: 25,
  },

  icone: {
    fontSize: 42,
    marginBottom: 8,
  },

  titulo: {
    fontSize: 28,
    fontWeight: 'bold',
    color: '#1e3a8a',
    marginBottom: 6,
  },

  subtitulo: {
    fontSize: 14,
    color: '#64748b',
    textAlign: 'center',
  },

  campo: {
    height: 52,
    backgroundColor: '#f8fafc',
    borderWidth: 1,
    borderColor: '#e2e8f0',
    borderRadius: 12,
    paddingHorizontal: 16,
    fontSize: 16,
    color: '#1e293b',
    marginBottom: 14,
  },

  botaoCadastro: {
    height: 54,
    backgroundColor: '#2563eb',
    borderRadius: 12,
    alignItems: 'center',
    justifyContent: 'center',
    marginTop: 8,

    shadowColor: '#2563eb',
    shadowOffset: {
      width: 0,
      height: 4,
    },
    shadowOpacity: 0.25,
    shadowRadius: 6,
    elevation: 4,
  },

  textoBotao: {
    color: '#ffffff',
    fontSize: 16,
    fontWeight: 'bold',
    letterSpacing: 0.2,
  },

  botaoVoltar: {
    height: 48,
    alignItems: 'center',
    justifyContent: 'center',
    marginTop: 8,
  },

  textoVoltar: {
    color: '#2563eb',
    fontSize: 15,
    fontWeight: '600',
  },

  rodape: {
    textAlign: 'center',
    color: '#94a3b8',
    fontSize: 12,
    marginTop: 18,
  },

});